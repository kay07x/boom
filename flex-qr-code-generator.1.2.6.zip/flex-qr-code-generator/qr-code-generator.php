<?php

/**
 * Plugin Name: Flex QR Code Generator
 * Description: Generate customized or automated Nice QR codes for any page, posts or products and show the qrcode with shortcode, widget or block.
 * Plugin URI:  https://devsbrain.com/wordpress-plugins/flex-qr-code-generator/
 * Author:      Devsbrain
 * Author URI:  https://devsbrain.com
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Version:     1.2.6
 * Text Domain: flex-qr-code-generator
 *
 * @package flex-qr-code-generator
 */

// Ensure WordPress functions are available if run directly
if (! defined('ABSPATH')) {
  require_once(dirname(__FILE__, 4) . '/wp-load.php');
}
if (!defined('FLEXQR_CODE_GENERATOR_PATH')) {
  define('FLEXQR_CODE_GENERATOR_PATH', plugin_dir_path(__FILE__));
}
if (!defined('FLEXQR_CODE_GENERATOR_URI')) {
  define('FLEXQR_CODE_GENERATOR_URI', plugin_dir_url(__FILE__));
}
class FlexQrCodeGenerator
{
  function __construct()
  {
    register_activation_hook(__FILE__, [$this, 'flexqr_code_generator_activate']);
    register_deactivation_hook(__FILE__, [$this, 'flexqr_code_generator_deactivate']);
    add_action('init', array($this, 'flexqr_includes'));
    add_action('admin_enqueue_scripts', [$this, 'flexqr_code_generator_scripts']);
    add_action('admin_menu', [$this, 'flexqr_code_generator_menu']);

    add_action('wp_ajax_flexqr_save_qr', [$this, 'save_qr_code_to_db']);
    // add_action('wp_ajax_nopriv_flexqr_save_qr', [$this, 'save_qr_code_to_db']);

    // update qr
    add_action('wp_ajax_flexqr_update_qr', [$this, 'update_qr_code']);
    add_action('wp_ajax_nopriv_flexqr_update_qr', [$this, 'update_qr_code']);

    add_action('wp_ajax_flexqr_fetch_qr_code', [$this, 'fetch_qr_code']);
    add_action('wp_ajax_nopriv_flexqr_fetch_qr_code', [$this, 'fetch_qr_code']);

    // search qr code by name
    add_action('wp_ajax_flexqr_search_qr_code_by_name', [$this, 'search_qr_code']);
    add_action('wp_ajax_nopriv_flexqr_search_qr_code_by_name', [$this, 'search_qr_code']);

    // fetch contents by type
    add_action('wp_ajax_flexqr_fetch_content_by_type', [$this, 'fetch_content_by_type']);
    add_action('wp_ajax_nopriv_flexqr_fetch_content_by_type', [$this, 'fetch_content_by_type']);

    // upload logo
    // removed 

    // shortcodes
    add_shortcode('flexqr_code', [$this, 'flexqr_code_shortcode']);

    // meta box
    add_action('add_meta_boxes', [$this, 'flexqr_code_meta_box']);

    // qr code to posts
    add_filter('the_content', [$this, 'add_qr_code_to_post_in_content']);

    // woocomerce order details
    // removed

    // block
    add_action('enqueue_block_editor_assets', [$this, 'flex_qr_block_assets']);

    // settings
    add_action('init', [$this, 'flexqr_register_settings']);

    // qr tracking
    add_action('template_redirect', [$this, 'handle_qr_tracking_redirect']);

    add_action('wp_ajax_download_qr_code', function () {
      if (!isset($_GET['post_id'])) {
        wp_send_json_error(['message' => 'Invalid post ID'], 404);
      }

      $post_id = intval($_GET['post_id']);
      $post = get_post($post_id);

      if (!$post || $post->post_status !== 'publish') {
        wp_send_json_error(['message' => 'Post not found or not published'], 404);
      }

      $qr_code_url = get_permalink($post_id);

      $format = !empty($_GET['format']) ? $_GET['format'] : 'png';
      $qr_code_image_url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&format=' . $format . '&data=' . urlencode($qr_code_url);


      // Fetch QR code image
      $image_data = file_get_contents($qr_code_image_url);

      if ($image_data === false) {
        wp_send_json_error(['message' => 'Failed to fetch QR code'], 404);
      }
      $filename = 'qr_code.' . $format;
      // Set headers for file download
      header('Content-Description: File Transfer');
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename="' . $filename . '"');
      header('Expires: 0');
      header('Cache-Control: must-revalidate');
      header('Pragma: public');
      header('Content-Length: ' . strlen($image_data));
      echo json_encode(esc_url ($image_data));
      exit;
    });
  }

  public function flexqr_includes()
  {
    include "inc/flexqr-helpers.php";
    // include "inc/flexqr-metabox.php";
    include "inc/flexqr-settings.php";
    include "inc/flexqr-track.php";
    include "views/flexqr-create-form.php";

    // pro
    if (file_exists(FLEXQR_CODE_GENERATOR_PATH . 'inc/classes/class-flexqr-pro-feature.php')) {
      include FLEXQR_CODE_GENERATOR_PATH . 'inc/classes/class-flexqr-pro-feature.php';
    }
  }

  function flexqr_code_generator_activate()
  {
    // Code to run when plugin is activated
    // Alter database
    include FLEXQR_CODE_GENERATOR_PATH . "inc/classes/class-flexqr-database.php";
  }

  function flexqr_code_generator_deactivate()
  {
    // Code to run when plugin is deactivated
  }

  public function flexqr_code_generator_scripts()
  {
    wp_enqueue_style('flexqr-code-generator-style', FLEXQR_CODE_GENERATOR_URI . 'flexqr-code-generator.css', array(), '1.2.6');
    wp_enqueue_script('flexqr-code-generator-script', FLEXQR_CODE_GENERATOR_URI . 'flexqr-code-generator.js', array('jquery'));
    wp_enqueue_script('jquery-script', "https://code.jquery.com/jquery-3.6.4.min.js", array('jquery'), true);

    // Enqueue WordPress API fetch
    wp_enqueue_script('wp-api-fetch');

    wp_enqueue_script('flexqr-admin-scripts', plugin_dir_url(__FILE__) . 'build/Admin.js', ['wp-element'], wp_rand(), true);

    // wp_enqueue_script('flexqr-metabox-scripts', plugin_dir_url(__FILE__) . 'build/metabox.js', ['wp-element'], wp_rand(), true);

    wp_enqueue_style('flexqr-admin-style', plugin_dir_url(__FILE__) . 'build/index.css');
    // wp_enqueue_style('flexqr-frontend-style', plugin_dir_url(__FILE__) . 'build/index.css');

    wp_localize_script('flexqr-admin-scripts', 'flexQrApi', [
      'apiUrl' => home_url('/wp-json'),
      'nonce' => wp_create_nonce('wp_rest'),
    ]);

    $is_woocommerce_active = function_exists('WC');
    wp_localize_script('flexqr-admin-scripts', 'flex_qr_wc', [
      'isWooCommerceActive' => $is_woocommerce_active,
    ]);

    // for deactivation feedback
    // wp_localize_script('flexqr-admin-scripts', 'flexqrDeactivation', [
    //   'pluginSlug' => 'flex-qr-code-generator-pro',
    // ]);

    $plugin_data = get_plugin_data(__FILE__);
    $plugin_name = $plugin_data['Name'];
    $plugin_slug = strtolower(str_replace(' ', '-', $plugin_name));
    wp_localize_script('flexqr-admin-scripts', 'flexqrDeactivation', [
      'pluginSlug' => $plugin_slug,
    ]);
  }

  function flexqr_code_generator_menu()
  {
    add_menu_page('QR Code Generator Options', 'Flex QR Code', 'manage_options', 'flexqr-code-generator', 'flexqr_code_generator_options', 'dashicons-screenoptions');

    // if (function_exists('WC')) {
    //   add_submenu_page('flexqr-code-generator', 'WC QR Design', 'WC QR Design', 'manage_options', 'flexqr-code-qr-options', 'flexqr_code_qr_options');
    // }

    add_submenu_page('flexqr-code-generator', 'QR Design', 'QR Design', 'manage_options', 'flexqr-code-qr-options', 'flexqr_code_qr_options');

    add_submenu_page('flexqr-code-generator', 'Settings', 'Settings', 'manage_options', 'flexqr-code-settings', 'flexqr_code_settings');

    // edit page
    add_submenu_page(
      null,
      'Edit QR Code',
      'Edit QR Code',
      'manage_options',
      'flexqr-edit',
      [$this, 'flexqr_edit_qr_page']
    );
  }

  // helper
  function add_tracking_param_to_url($url, $tracking_code)
  {
    return add_query_arg('fqrcgtr', $tracking_code, $url);
  }

  // function save_qr_code_to_db()
  // {

  //   if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'wp_rest') ) {
  //       wp_send_json_error(['message' => 'Security check failed.']);
  //       wp_die();
  //   }

  //   if (isset($_POST['qrData'])) {
  //     global $wpdb;
  //     $qrData = json_decode(stripslashes($_POST['qrData']), true);
  //     $qrName = isset($_POST['qrName']) ? $_POST['qrName'] : null;
  //     $isTrackingEnabled = $_POST['isTrackingEnabled'] === 'true';

  //     if (!$qrData) {
  //       echo 'Invalid QR data.';
  //       wp_die();
  //     }

  //     $originalText = sanitize_text_field($qrData['data']);

  //     $input_data = array(
  //       'text' => $originalText,
  //       'qr_data' => json_encode($qrData, JSON_UNESCAPED_SLASHES),
  //     );

  //     // Add qr_name only if it's not null
  //     if ($qrName !== null) {
  //       $input_data['qr_name'] = sanitize_text_field($qrName);
  //     }

  //     // Save it to the database first to get the ID
  //     $result = $wpdb->insert(
  //       $wpdb->prefix . 'qr_codes',
  //       $input_data
  //     );

  //     if (!$result) {
  //       wp_send_json_error(['message' => 'Error saving QR code.']);
  //       wp_die();
  //     }

  //     $inserted_id = $wpdb->insert_id;

  //     // Handle the logo (file upload) - now that we have the ID
  //     $logo_url = '';

  //     if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
  //       $logo = $_FILES['logo'];
  //       $upload_dir = wp_upload_dir();

  //       $file_ext = pathinfo($logo['name'], PATHINFO_EXTENSION);
  //       $file_name = pathinfo($logo['name'], PATHINFO_FILENAME);

  //       // Create new filename with ID
  //       $new_file_name = $file_name . '_' . $inserted_id . '.' . $file_ext;
  //       $file_path = $upload_dir['path'] . '/' . $new_file_name;

  //       if (move_uploaded_file($logo['tmp_name'], $file_path)) {
  //         $logo_url = $upload_dir['url'] . '/' . $new_file_name;
  //         $logo_url = str_replace(home_url(), '', $logo_url);

  //         // Update the database with the logo URL
  //         $wpdb->update(
  //           $wpdb->prefix . 'qr_codes',
  //           ['logo_url' => $logo_url],
  //           ['id' => $inserted_id]
  //         );
  //       }
  //     }

  //     // qr_image handling
  //     $qr_image_url = '';

  //     if (isset($_FILES['qr_image']) && $_FILES['qr_image']['error'] === UPLOAD_ERR_OK) {
  //       $qr_image = $_FILES['qr_image'];
  //       $upload_dir = wp_upload_dir();

  //       $file_ext = pathinfo($qr_image['name'], PATHINFO_EXTENSION);
  //       $file_name = pathinfo($qr_image['name'], PATHINFO_FILENAME);

  //       // Create new filename with ID
  //       $new_file_name = $file_name . '_' . $inserted_id . '.' . $file_ext;
  //       $file_path = $upload_dir['path'] . '/' . $new_file_name;

  //       if (move_uploaded_file($qr_image['tmp_name'], $file_path)) {
  //         $qr_image_url = $upload_dir['url'] . '/' . $new_file_name;
  //         $qr_image_url = str_replace(home_url(), '', $qr_image_url);

  //         // Update the database with the QR image URL
  //         $wpdb->update(
  //           $wpdb->prefix . 'qr_codes',
  //           ['qr_image_url' => $qr_image_url],
  //           ['id' => $inserted_id]
  //         );
  //       }
  //     }

  //     if ($isTrackingEnabled) {
  //       $trackedUrl = $this->add_tracking_param_to_url($originalText, $inserted_id);

  //       $qrData['data'] = $trackedUrl;

  //       $wpdb->update(
  //         $wpdb->prefix . 'qr_codes',
  //         ['qr_data' => json_encode($qrData, JSON_UNESCAPED_SLASHES)],
  //         ['id' => $inserted_id]
  //       );
  //     }

  //     wp_send_json_success([
  //       'message' => 'QR code saved successfully.',
  //       'id' => $inserted_id,
  //       'finalUrl' => $isTrackingEnabled ? $trackedUrl : $originalText,
  //     ]);

  //   } else {
  //     wp_send_json_error(array('message' => 'Missing QR data.'));
  //   }

  //   wp_die();
  // }
  function save_qr_code_to_db()
  {
    if (! is_user_logged_in() || ! current_user_can('upload_files')) {
      wp_send_json_error(['message' => 'Unauthorized access.']);
      wp_die();
    }

    // Verify nonce
    if (! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'wp_rest')) {
      wp_send_json_error(['message' => 'Security check failed.']);
      wp_die();
    }

    if (! isset($_POST['qrData'])) {
      wp_send_json_error(['message' => 'Missing QR data.']);
      wp_die();
    }

    global $wpdb;

    $qrData = json_decode(stripslashes($_POST['qrData']), true);
    if (! $qrData || ! isset($qrData['data'])) {
      wp_send_json_error(['message' => 'Invalid QR data.']);
      wp_die();
    }

    $qrName = isset($_POST['qrName']) ? sanitize_text_field($_POST['qrName']) : null;
    $isTrackingEnabled = isset($_POST['isTrackingEnabled']) && $_POST['isTrackingEnabled'] === 'true';
    $originalText = sanitize_text_field($qrData['data']);

    $input_data = [
      'text'     => $originalText,
      'qr_data'  => wp_json_encode($qrData, JSON_UNESCAPED_SLASHES),
    ];

    if ($qrName) {
      $input_data['qr_name'] = $qrName;
    }

    // Insert to DB
    $result = $wpdb->insert(
      $wpdb->prefix . 'qr_codes',
      $input_data
    );

    if (! $result) {
      wp_send_json_error(['message' => 'Error saving QR code.']);
      wp_die();
    }

    $inserted_id = $wpdb->insert_id;

    require_once(ABSPATH . 'wp-admin/includes/file.php');

    // Allowed MIME types
    $allowed_mimes = [
      'jpg|jpeg|jpe' => 'image/jpeg',
      'png'          => 'image/png',
      'gif'          => 'image/gif',
      'webp'         => 'image/webp',
      'svg'          => 'image/svg+xml',
    ];

    $upload_overrides = [
      'test_form' => false,
      'mimes'     => $allowed_mimes,
    ];

    // Handle logo upload
    if (! empty($_FILES['logo']['name'])) {
      $uploaded = wp_handle_upload($_FILES['logo'], $upload_overrides);

      if (isset($uploaded['error'])) {
        wp_send_json_error(['message' => 'Logo upload failed: ' . $uploaded['error']]);
        wp_die();
      }

      $logo_url = esc_url_raw($uploaded['url']);
      $wpdb->update(
        $wpdb->prefix . 'qr_codes',
        ['logo_url' => $logo_url],
        ['id' => $inserted_id]
      );
    }

    // Handle QR image upload
    if (! empty($_FILES['qr_image']['name'])) {
      $uploaded_qr = wp_handle_upload($_FILES['qr_image'], $upload_overrides);

      if (isset($uploaded_qr['error'])) {
        wp_send_json_error(['message' => 'QR image upload failed: ' . $uploaded_qr['error']]);
        wp_die();
      }

      $qr_image_url = esc_url_raw($uploaded_qr['url']);
      $wpdb->update(
        $wpdb->prefix . 'qr_codes',
        ['qr_image_url' => $qr_image_url],
        ['id' => $inserted_id]
      );
    }

    // Handle tracking
    if ($isTrackingEnabled && method_exists($this, 'add_tracking_param_to_url')) {
      $trackedUrl = $this->add_tracking_param_to_url($originalText, $inserted_id);
      $qrData['data'] = $trackedUrl;

      $wpdb->update(
        $wpdb->prefix . 'qr_codes',
        ['qr_data' => wp_json_encode($qrData, JSON_UNESCAPED_SLASHES)],
        ['id' => $inserted_id]
      );
    }

    wp_send_json_success([
      'message'  => 'QR code saved successfully.',
      'id'       => $inserted_id,
      'finalUrl' => $isTrackingEnabled ? $trackedUrl : $originalText,
    ]);

    wp_die();
  }


  public function update_qr_code()
  {
    if (isset($_POST['qrData']) && isset($_POST['qrId'])) {
      global $wpdb;
      $qrData = json_decode(stripslashes($_POST['qrData']), true);
      $qrId = intval($_POST['qrId']);
      $qrName = isset($_POST['qrName']) ? $_POST['qrName'] : null;
      $isTrackingEnabled = $_POST['isTrackingEnabled'] === 'true';

      if (!$qrData) {
        wp_send_json_error(['message' => 'Invalid QR data.']);
        wp_die();
      }

      // Get the existing QR code data
      $table_name = $wpdb->prefix . 'qr_codes';
      $existing_qr = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $qrId));

      if (!$existing_qr) {
        wp_send_json_error(['message' => 'QR code not found.']);
        wp_die();
      }

      $originalText = sanitize_text_field($qrData['data']);
      $update_data = array(
        'text' => $originalText,
        'qr_data' => json_encode($qrData, JSON_UNESCAPED_SLASHES),
      );

      // Add qr_name only if it's not null
      if ($qrName !== null) {
        $update_data['qr_name'] = sanitize_text_field($qrName);
      } else {
        $update_data['qr_name'] = null;
      }

      // Handle the logo (file upload)
      if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $logo = $_FILES['logo'];
        $upload_dir = wp_upload_dir();

        // Get file info and create new filename with ID
        $file_ext = pathinfo($logo['name'], PATHINFO_EXTENSION);
        $file_name = pathinfo($logo['name'], PATHINFO_FILENAME);
        $new_file_name = $file_name . '_' . $qrId . '.' . $file_ext;
        $file_path = $upload_dir['path'] . '/' . $new_file_name;

        if (move_uploaded_file($logo['tmp_name'], $file_path)) {
          $logo_url = $upload_dir['url'] . '/' . $new_file_name;
          $logo_url = str_replace(home_url(), '', $logo_url);
          $update_data['logo_url'] = $logo_url;

          // Delete old logo file if it exists
          if (!empty($existing_qr->logo_url)) {
            $old_logo_path = str_replace($upload_dir['url'], $upload_dir['path'], home_url($existing_qr->logo_url));
            if (file_exists($old_logo_path)) {
              @unlink($old_logo_path);
            }
          }
        }
      } elseif (isset($_POST['removeLogo']) && $_POST['removeLogo'] === 'true') {
        // Remove logo if requested
        if (!empty($existing_qr->logo_url)) {
          $upload_dir = wp_upload_dir();
          $old_logo_path = str_replace($upload_dir['url'], $upload_dir['path'], home_url($existing_qr->logo_url));
          if (file_exists($old_logo_path)) {
            @unlink($old_logo_path);
          }
        }
        $update_data['logo_url'] = '';
      }

      // qr_image handling
      if (isset($_FILES['qr_image']) && $_FILES['qr_image']['error'] === UPLOAD_ERR_OK) {
        $qr_image = $_FILES['qr_image'];
        $upload_dir = wp_upload_dir();
        // Get file info and create new filename with ID
        $file_ext = pathinfo($qr_image['name'], PATHINFO_EXTENSION);
        $file_name = pathinfo($qr_image['name'], PATHINFO_FILENAME);
        $new_file_name = $file_name . '_' . $qrId . '.' . $file_ext;
        $file_path = $upload_dir['path'] . '/' . $new_file_name;

        // Delete old QR image file if it exists
        if (!empty($existing_qr->qr_image_url)) {
          $old_qr_image_path = str_replace($upload_dir['url'], $upload_dir['path'], home_url($existing_qr->qr_image_url));
          if (file_exists($old_qr_image_path)) {
            @unlink($old_qr_image_path);
          }
        }

        if (move_uploaded_file($qr_image['tmp_name'], $file_path)) {
          $qr_image_url = $upload_dir['url'] . '/' . $new_file_name;
          $qr_image_url = str_replace(home_url(), '', $qr_image_url);
          $update_data['qr_image_url'] = $qr_image_url;
        }
      }

      // Update the database
      $result = $wpdb->update(
        $table_name,
        $update_data,
        array('id' => $qrId)
      );

      if ($result === false) {
        wp_send_json_error(['message' => 'Error updating QR code.']);
        wp_die();
      }

      $trackedUrl = '';
      if ($isTrackingEnabled) {
        $trackedUrl = $this->add_tracking_param_to_url($originalText, $qrId);

        $qrData['data'] = $trackedUrl;

        $wpdb->update(
          $table_name,
          ['qr_data' => json_encode($qrData, JSON_UNESCAPED_SLASHES)],
          ['id' => $qrId]
        );
      }

      wp_send_json_success([
        'message' => 'QR code updated successfully.',
        'id' => $qrId,
        'finalUrl' => $isTrackingEnabled ? $trackedUrl : $originalText,
      ]);
    } else {
      wp_send_json_error(array('message' => 'Missing QR data or ID.'));
    }

    wp_die();
  }

  function fetch_qr_code()
  {
    global $wpdb;

    $default_per_page = 10;
    $per_page_options = array(10, 20, 50, 100);

    // Get per_page and paged from POST data
    $per_page = isset($_POST['per_page']) && in_array(absint($_POST['per_page']), $per_page_options)
      ? absint($_POST['per_page'])
      : $default_per_page;

    $page = !empty($_POST['page']) ? absint($_POST['page']) : 1;

    $offset = ($page - 1) * $per_page;

    // Query to get the total number of QR codes
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix . "qr_codes");

    // Query to fetch the QR codes based on pagination
    $qr_codes = $wpdb->get_results(
      $wpdb->prepare(
        "SELECT * FROM " . $wpdb->prefix . "qr_codes ORDER BY id DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
      )
    );

    // print_r($qr_codes);
    if ($qr_codes === false) {
      wp_send_json_error(array('message' => 'Failed to fetch QR codes'));
    } else {
      wp_send_json_success(array(
        'qrCodes' => $qr_codes,
        'totalItems' => $total_items
      ));
    }
  }

  function search_qr_code()
  {
    global $wpdb;

    if (isset($_POST['qrName']) && !empty($_POST['qrName'])) {
      $qrName = sanitize_text_field($_POST['qrName']);

      $qr_codes = $wpdb->get_results(
        $wpdb->prepare(
          "SELECT * FROM " . $wpdb->prefix . "qr_codes WHERE qr_name LIKE %s OR text LIKE %s ORDER BY id DESC",
          '%' . $wpdb->esc_like($qrName) . '%',
          '%' . $wpdb->esc_like($qrName) . '%'
        )
      );


      if ($qr_codes === false) {
        wp_send_json_error(array('message' => 'Failed to fetch QR codes'));
      }

      wp_send_json_success(array(
        'qrCodes' => $qr_codes,
      ));
    }

    wp_send_json_error(array('message' => 'No Valid Input'));
  }

  function fetch_content_by_type()
  {
    $content_type = isset($_POST['content_type']) ? sanitize_text_field($_POST['content_type']) : '';
    // $content_type = $_POST['content_type'];


    if (empty($content_type) || !in_array($content_type, ['post', 'page', 'product'])) {
      wp_send_json_error(['message' => 'Invalid content type.'], 400);
    }

    if ($content_type === 'product' && !function_exists('WC')) {
      wp_send_json_success(['errMessage' => 'Woocommerce is not active.'], 200);
    }

    $args = [
      'post_type' => $content_type,
      'posts_per_page' => -1,
      'post_status' => 'publish'
    ];

    $posts = get_posts($args);

    $response = [];

    foreach ($posts as $post) {
      $response[] = [
        'title' => get_the_title($post->ID),
        'link' => get_permalink($post->ID)
      ];
    }

    wp_send_json_success($response, 200, JSON_UNESCAPED_SLASHES);
  }

  function flexqr_code_shortcode($atts)
  {
    $atts = shortcode_atts(array(
      'qr-id' => '',
      'qr-text' => '',
      'qr-size' => null,
      'qr-data' => '',
      'qr-type' => '',
      'qr-btn' => ''
    ), $atts);

    $qr_type = $atts['qr-type'];
    $qr_btn = $atts['qr-btn'];
    $qr_id = $atts['qr-id'];
    $qr_text = $atts['qr-text'];
    $qr_size = $atts['qr-size'];
    $qr_data_attr = isset($atts['qr-data']) ? urldecode($atts['qr-data']) : '';

    $qr_data = [];
    $qr_logo_url = '';

    if ((empty($qr_id) || $qr_id === 'undefined') && empty($qr_text) && empty($qr_data_attr)) {
      return 'Both QR ID and QR Text are empty';
    }

    if (!empty($qr_id)) {
      global $wpdb;
      $query = "SELECT qr_data, logo_url FROM " . $wpdb->prefix . "qr_codes WHERE id=%d";
      $qr_code = $wpdb->get_row($wpdb->prepare($query, $qr_id));

      $data = json_decode($qr_code->qr_data, true);
      $qr_size = isset($data['width']) ? (int) $data['width'] : 150;

      if (!empty($qr_code->logo_url)) {
        $qr_logo_url = home_url() . $qr_code->logo_url;
        $file_path = ABSPATH . ltrim($qr_code->logo_url, '/');

        if (file_exists($file_path)) {
          $data['image'] = $qr_logo_url;
        } else {
          $data['image'] = '';
        }
      } else {
        $data['image'] = '';
      }

      $qr_data = $data;
    }

    if (empty($qr_id)) {

      switch ($qr_type) {
        case 'GLOBAL_POST_STYLE':
          $flexqr_settings = get_option('flexqr_settings');
          $qr_style = $flexqr_settings['wc_style_settings'];
          $do_btn = $flexqr_settings['general_settings']['flexqr_show_download_btn'];

          $qr_data = json_decode($qr_style, true);
          $qr_data['data'] = $qr_text;
          $qr_btn = $do_btn ? 'true' : 'false';
          break;

        case 'GLOBAL_WC_STYLE':
          $flexqr_settings = get_option('flexqr_settings');
          $qr_style = $flexqr_settings['wc_style_settings'];
          $do_btn = $flexqr_settings['general_settings']['flexqr_show_download_btn'];

          $qr_data = json_decode($qr_style, true);
          $qr_data['data'] = $qr_text;
          $qr_btn = $do_btn ? 'true' : 'false';
          break;
        default:
          if (!empty($qr_data_attr)) {
            $qr_data = json_decode($qr_data_attr, true);
          }
          $qr_data['data'] = $qr_text;
          break;
      }
    }

    // if ($qr_type == 'GLOBAL_POST_STYLE') {
    //   $flexqr_settings = get_option('flexqr_settings');
    //   $qr_style = $flexqr_settings['wc_style_settings'];

    //   $qr_data = json_decode($qr_style, true);
    //   $qr_data['data'] = $qr_text;
    // } else {
    //   if (!empty($qr_data_attr)) {
    //     $qr_data = json_decode($qr_data_attr, true);
    //   }
    // }

    wp_enqueue_style('flexqr-admin-style', plugin_dir_url(__FILE__) . 'build/index.css');

    wp_enqueue_script('qr-code-shortcode-script', plugin_dir_url(__FILE__) . 'build/QrShortCode.js', ['wp-element'], null, true);

    // TODO: Think about why we are sending all these data
    // return "<div class='flexqr-code-shortcode-container' 
    //          data-size='" . esc_attr($qr_size) . "' 
    //          data-logo-url='" . esc_attr($qr_logo_url) . "' 
    //          data-text='" . esc_attr($qr_text) . "'
    //          data-qr='" . json_encode($qr_data) . "'
    //          data-btn='" . esc_attr($qr_btn) . "'>
    //         </div>";

    return "<div class='flexqr-code-shortcode-container' 
    data-qr='" . json_encode($qr_data) . "'
    data-btn='" . esc_attr($qr_btn) . "'>
    </div>";
  }

  function add_qr_code_to_post_in_content($content)
  {
    $flexqr_settings = get_option('flexqr_settings');

    $show_qr_posts = isset($flexqr_settings['general_settings']['flexqr_show_qr_posts'])
      ? $flexqr_settings['general_settings']['flexqr_show_qr_posts']
      : false;

    if ($show_qr_posts && is_single() && is_main_query()) {
      global $post;

      $post_url = get_permalink($post->ID);

      $shortcode_text = '[flexqr_code qr-btn="true" qr-type="GLOBAL_POST_STYLE" qr-text="' . $post_url . '"]';

      $content .= do_shortcode($shortcode_text);
    }
    return $content;
  }

  public function flex_qr_block_assets()
  {
    wp_enqueue_script(
      'flex-qr-block',
      FLEXQR_CODE_GENERATOR_URI . 'build/QrBlock.js',
      array('wp-blocks', 'wp-editor', 'wp-components'),
      filemtime(FLEXQR_CODE_GENERATOR_PATH . 'build/QrBlock.js'),
      true
    );
  }

  function flexqr_code_meta_box()
  {
    $flexqr_settings = get_option('flexqr_settings');
    $show_metabox = $flexqr_settings['general_settings']['flexqr_show_metabox'] ?? false;

    if ($show_metabox) {
      add_meta_box(
        'flexqr_editor', // ID of the meta box
        'FLEXQR Code', // Title of the meta box
        [$this, 'flexqr_code_meta_box_html'], // Callback function to display the meta box
        ['post', 'page'], // Apply to both posts and pages
        'side', // Position
        'high' // Priority
      );
    }
  }

  function flexqr_code_meta_box_html($post)
  {

    if ($post->post_status === 'publish') {
      $qr_code_text = get_permalink($post->ID);

      $shortcode_text = '[flexqr_code qr-text="' . $qr_code_text . '"]';

      wp_localize_script('flexqr-admin-scripts', 'qrData', [
        'qrText' => esc_js($qr_code_text),
        'shortCode' => esc_js($shortcode_text),
      ]);

      // react 
      echo '<div class="metabox-download-wrapper">
      <div id="meta-download-qr"></div>
      </div>';
    } else {
      echo '<strong>Please publish the post to generate the QR code.</strong>';
    }
  }

  function flexqr_register_settings()
  {
    $default_settings = [
      'general_settings' => [
        'flexqr_show_metabox' => true,
        'flexqr_show_qr_woocommerce_products' => false,
        'flexqr_show_qr_posts' => false,
        'flexqr_show_download_btn' => true,
      ],
      'wc_style_settings' => '',
    ];

    $settings_schema = [
      'type' => 'object',
      'properties' => [
        'general_settings' => [
          'type' => 'object',
          'properties' => [
            'flexqr_show_metabox' => [
              'type' => 'boolean',
            ],
            'flexqr_show_qr_woocommerce_products' => [
              'type' => 'boolean',
            ],
            'flexqr_show_qr_posts' => [
              'type' => 'boolean',
            ],
            'flexqr_show_download_btn' => [
              'type' => 'boolean',
            ],
          ],
        ],
        'wc_style_settings' => [
          'type' => 'string',
        ],
      ],
    ];

    register_setting('general', 'flexqr_settings', [
      'type' => 'array',
      'description' => 'FlexQR Settings',
      'show_in_rest' => ['schema' => $settings_schema],
      'default' => $default_settings
    ]);


    register_setting('general', 'flexqr_license_key', [
      'type' => 'string',
      'description' => 'Enter your FlexQR license key',
      'sanitize_callback' => 'sanitize_text_field',
      'show_in_rest' => true,
      'default' => '',
    ]);
  }

  function handle_qr_tracking_redirect()
  {
    if (!isset($_GET['fqrcgtr'])) {
      return;
    }

    $tracking_id = intval($_GET['fqrcgtr']);
    if ($tracking_id <= 0) {
      return;
    }

    global $wpdb;

    // Fetch the QR record
    $table = $wpdb->prefix . 'qr_codes';
    $qr_record = $wpdb->get_row(
      $wpdb->prepare("SELECT * FROM $table WHERE id = %d", $tracking_id),
      ARRAY_A
    );

    if (!$qr_record) {
      return;
    }

    // Extract clean URL from qr_data JSON
    $qr_data = json_decode($qr_record['qr_data'], true);
    $target_url = $qr_data['data'] ?? null;

    if (!$target_url) {
      return;
    }

    $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $timestamp = current_time('mysql');
    $language = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : 'unknown';

    $new_tracking_object = array(
      "ip" => $ip_address,
      "user_agent" => $user_agent,
      "timestamp" => $timestamp,
      "language" => $language,
    );

    $existing_tracking_details = json_decode($qr_record['tracking_details'], true);
    if (!is_array($existing_tracking_details)) {
      $existing_tracking_details = array();
    }

    $existing_tracking_details[] = $new_tracking_object;

    $updated_tracking_details = json_encode($existing_tracking_details);

    $wpdb->query(
      $wpdb->prepare(
        "UPDATE {$wpdb->prefix}qr_codes SET tracking = tracking + %d, tracking_details = %s WHERE id = %d",
        1,
        $updated_tracking_details,
        $tracking_id
      )
    );

    wp_redirect(remove_query_arg('fqrcgtr', $target_url));
    exit;
  }

  function flexqr_edit_qr_page()
  {
    if (!current_user_can('manage_options')) {
      wp_die('Unauthorized');
    }

    $qr_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    echo '<script>document.title = "Edit QR Code";</script>';
    echo '<div class="flexqr-qr-edit-wrapper">';
    echo '<div id="flexqr-qr-edit-root"></div>';
    echo '</div>';

    // run the query
    global $wpdb;
    $table_name = $wpdb->prefix . 'qr_codes';

    $qr_data = $wpdb->get_row($wpdb->prepare(
      "SELECT * FROM $table_name WHERE id = %d",
      $qr_id
    ));

    $site_url = site_url();

    wp_localize_script('flexqr-admin-scripts', 'qrEditData', [
      'qr_code' => $qr_data ? $qr_data : null,
      'site_domain' => $site_url,
    ]);
  }
}

new FlexQrCodeGenerator();
