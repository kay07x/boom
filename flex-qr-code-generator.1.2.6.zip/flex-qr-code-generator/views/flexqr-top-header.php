<div class="flex-qr-code-top-header" >
   <h2>FlexQR Code Generator</h2> - <a href="https://devsbrain.com">by DevsBrain</a>
</div>
<script>
   var FLEXQR_CODE_GENERATOR_URI = <?php echo json_encode( esc_url( FLEXQR_CODE_GENERATOR_URI ) ); ?>;
</script>