<?php

// require_once __DIR__.'/../vendor/autoload.php';
// require_once __DIR__.'/../inc/flexqr-generate.php';

if (!function_exists('flexqr_display_generator_form')) {
  function flexqr_display_generator_form()
  {
    /* echo '<form action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post" id="qrForm">';?>
    <input type="hidden" name="action" value="flexqr_generate_qr">
            <?php wp_nonce_field('qrcode_nonce', 'qrcode_nonce'); 
    echo '<table><tr><td><label for="flexqrcode_code_text">Enter text to encode in QR code:</label></td>';  
    echo '<td>
    <textarea id="flexqrcode_code_text" placeholder="text/url/anything"  name="qr_code_text" required style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;"></textarea>
  </td>
  <td>
    <select id="flexqrcode_select_page_option" name="qr_code_input" style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;">
      <option value="">Select</option>
      <option value="page">page</option>
      <option value="post">post</option>';
      if (function_exists('wc_get_products')) {
        echo '<option value="product">product</option>';
      }
      echo' </select>
  </td>
  <td id="flexqrcode_input_page">
  <select name="page-dropdown" style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;">
      <option value="">' . esc_attr( __( 'Select page' ) ) . '</option>';
      
    $pages = get_pages();
    foreach ( $pages as $page ) {
    echo '<option value="' . get_page_link( $page->ID ) . '">' . $page->post_title . '</option>';
    }

    echo '</select>
    </td>
    <td id="flexqrcode_input_post">
    <select name="page-dropdown" style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;">
      <option value="">' . esc_attr( __( 'Select Posts' ) ) . '</option>';
      
    $posts = get_posts();
    foreach ( $posts as $post ) {
    echo '<option value="' . get_permalink( $post->ID ) . '">' . $post->post_title . '</option>';
    }
    echo '</select>
    </td>
    <td id="flexqrcode_input_product">
    <select name="page-dropdown" style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;">
      <option value="">' . esc_attr( __( 'Select Product' ) ) . '</option>';
      $args = array(

        'limit' => 10,
        'orderby' => 'date',
        'order' => 'DESC'
    
    );
    if (function_exists('wc_get_products')) {
    $products = wc_get_products($args);
    foreach ( $products as $product ) {
    echo '<option value="' .  get_permalink( $product->get_id() ) . '">' . $product->get_name() . '</option>';
    }
    }
    echo '</select>
    </td>
</tr>';


   //  echo '<br><br>';
    // echo '<tr><td><label for="qr_code_color">Select QR code color:</label></td>';
  //  echo '<td><input type="color" id="qr_code_bg_color" name="qr_code_bg_color" style=" display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; "></td></tr>';
   ?>
    <!-- <tr><td><label for="finderDark">Finder Pattern Color (Dark):</label></td>
    <td><input type="color" id="finderDark" name="finderDark" value="#000000"></td></tr>

    <tr><td><label for="finderDot">Finder Dot Color:</label></td>
    <td><input type="color" id="finderDot" name="finderDot" value="#FF0000"></td></tr>

    <tr><td><label for="alignmentDark">Alignment Pattern Color (Dark):</label></td>
    <td><input type="color" id="alignmentDark" name="alignmentDark" value="#00FF00"></td></tr> -->

    <tr><td><label for="eye_color">Eye Color:</label></td>
    <td><input type="color" id="eye_color" name="eye_color"></td></tr>

    <tr><td><label for="dot_color">Dot Color:</label></td>
    <td><input type="color" id="dot_color" name="dot_color"></td></tr>

    <!-- <tr><td><label for="background_color">background_color:</label></td>
    <td><input type="color" id="background_color" name="background_color"></td></tr> -->

    <label for="version">Select QR Code Version:</label>
    <select id="version" name="version">
        <?php for ($i = 7; $i <= 10; $i++): ?>
            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
        <?php endfor; ?>
    </select><br><br>
    
    
    <label for="circleRadius">Circle Radius (0.5 to 0.75):</label>
    <input type="number" id="circleRadius" name="circleRadius" min="0.5" max="0.75" step="0.05" value="0.5"><br><br>

    <tr><td><label for="drawCircularModules">Draw Circular Modules:</label></td>    
        <td><input style="width: 1px;" type="radio" id="image1" name="drawCircularModules" value="1">
        <label for="image1"><img src="<?php echo plugin_dir_url(__FILE__); ?>../dot.png" alt="Image 1" class="module-preview"></label></td>
        <td><input style="width: 1px;" type="radio" id="image2" name="drawCircularModules" value="0" checked>
        <label for="image2"><img src="<?php echo plugin_dir_url(__FILE__); ?>../round.png" alt="Image 2" class="module-preview"></label></td></tr>

   <?php
   echo '<tr><td><label for="qr_code_size">Size(150 X 150):</label></td>';
   echo '<td><input type="number" id="qr_code_size" name="qr_code_size" style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;"></td></tr>';
   echo '<tr><td><label for="qr_code_format">QR Format:</label></td>';
   echo '<td><select id="qr_code_format" name="qr_code_format" style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;">
   <option value="png">png</option>
   <option value="gif">gif</option>
   <option value="jpg">jpg</option>
   <option value="svg">svg</option>
   <option value="eps">eps</option>
   </select></td></tr>';
   echo '<tr><td><label for="qr_code_margin">Margin:</label></td>';
   echo '<td><input type="number" id="qr_code_margin" name="qr_code_margin" style="padding: 6px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 300px;"></td></tr>';
   echo '<tr><td colspan="2"><input type="submit" class="button button-primary" style="padding: 7px 20px; margin: 8px 0;" value="Generate QR Code"></td></tr></table>';
   echo '</form>';  

   echo '<div id="qrCodeOutput"></div>';
*/



  }
}

// if (!function_exists('flexqr_delete_qr')) {
//   function flexqr_delete_qr()
//   {
//     global $wpdb;
//     if (!empty($_POST['action']) && $_POST['action'] == 'delete_qrcode' && !empty($_POST['qrid'])) {
//       $id = absint($_POST['qrid']);  // Ensure valid ID
//       $table_name = $wpdb->prefix . 'qr_codes'; // Table name

//       // Delete the row with the given ID
//       $result = $wpdb->delete($table_name, array('id' => $id), array('%d'));

//       if ($result === false) {
//         wp_send_json_error(array('message' => 'Failed to delete QR code'));
//       } else {
//         wp_send_json_success(array('message' => 'QR code deleted successfully'));
//       }
//     }
//   }
// }


add_action('wp_ajax_delete_qrcode', 'flexqr_delete_qr');

if (!function_exists('flexqr_delete_qr')) {
  function flexqr_delete_qr()
  {
    global $wpdb;

    if (!empty($_POST['qrid'])) {
      $id = absint($_POST['qrid']);  // Ensure valid ID
      $table_name = $wpdb->prefix . 'qr_codes';

      // First get the QR code data to check for logo file
      $qr_code = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));

      if ($qr_code) {
        // Delete associated logo file if it exists
        if (!empty($qr_code->logo_url)) {
          $upload_dir = wp_upload_dir();
          $logo_path = str_replace($upload_dir['url'], $upload_dir['path'], home_url($qr_code->logo_url));

          if (file_exists($logo_path)) {
            @unlink($logo_path);
          }
        }

        // delete qr image
        if (!empty($qr_code->qr_image_url)) {
          $upload_dir = wp_upload_dir();
          $qr_image_path = str_replace($upload_dir['url'], $upload_dir['path'], home_url($qr_code->qr_image_url));

          if (file_exists($qr_image_path)) {
            @unlink($qr_image_path);
          }
        }

        // Delete the row with the given ID
        $result = $wpdb->delete($table_name, array('id' => $id), array('%d'));

        if ($result === false) {
          wp_send_json_error(array('message' => 'Failed to delete QR code'));
        } else {
          wp_send_json_success(array('message' => 'QR code deleted successfully'));
        }
      } else {
        wp_send_json_error(array('message' => 'QR code not found'));
      }
    } else {
      wp_send_json_error(array('message' => 'Missing QR code ID'));
    }

    wp_die();
  }
}

if (!function_exists('flexqr_code_generator_options')) {
  function flexqr_code_generator_options()
  {
    // global $wpdb;
    // flexqr_delete_qr();

    // Default items per page
    // $default_per_page = 10;

    // Available items per page options
    // $per_page_options = array(10, 20, 50, 100);

    // Get the selected items per page or use the default
    // $per_page = isset($_GET['per_page']) && in_array(absint($_GET['per_page']), $per_page_options) ? absint($_GET['per_page']) : $default_per_page;

    // Get the current page number
    // $page = !empty($_GET['paged']) ? absint($_GET['paged']) : 1;

    // $offset = ($page - 1) * $per_page;

    // Query the database to retrieve all of the user's generated QR codes
    // $qr_codes = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "qr_codes order by id desc LIMIT " . $per_page . " OFFSET $offset");

    // wp_localize_script('flexqr-admin-scripts', 'qrCodes', [
    //   'data' => wp_json_encode($qr_codes),
    // ]);

    // Display the plugin options page
    echo '<div class=" wrap">';
    // React Scan!!
    // echo '<script crossOrigin="anonymous" src="//unpkg.com/react-scan/dist/auto.global.js"></script>';
    // include_once "flexqr-top-header.php";

    // This is the input section
    // echo '<div class="flex-qr-code-wrapper"><div id="flex_qr_code_input"></div></div>';

    // Saved QR codes display
    // echo '<div class="flex-qr-code-wrapper"><div id="flex_qr_code_table"></div></div>';

    echo '<div class="flex-qr-code-wrapper"><div id="flex_qr_code_root"></div></div>';

    echo '</div>';

    // localizing domain for navigating to edit page
    $site_url = site_url();

    wp_localize_script('flexqr-admin-scripts', 'flexQrEdit', [
      'site_domain' => $site_url,
    ]);

  }
}