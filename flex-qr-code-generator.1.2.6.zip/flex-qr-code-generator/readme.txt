# Flex QR Code Generator
Description: Generate customized or automated Nice QR codes for any page, posts or products and show the qrcode with shortcode, widget or block.
Tags: qr code, qrcode generator, qr tracking, shortcode, woocommerce
Requires at least: 4.6
Tested up to: 6.8
Stable tag: 1.2.6
Version: 1.2.6
Requires PHP: 7.4.2
Text Domain: flex-qr-code-generator
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate customized or automated Nice QR codes for pages, posts or products and show the qrcode with shortcode, widget or block.

== Description ==
This is a simple plugin that allows you to create nice designed QR codes for your WordPress website and show the qrcode with shortcode, widget or block. You can select the color, gradient, design, and eye style for your QR codes and easily view and download all your created QR codes from the admin dashboard. You can copy the shortcode or add it from any editor like gutenberg, wpbakery, elementor and show it anywhere you want to show it.

## Free Version: Essential QR Code Functionality at Your Fingertips

1.  **Effortless QR Code Creation:**
    * Generate stunning QR codes directly within your WordPress admin panel.
    * Instantly create QR codes for your posts, pages, products, and more with a single click.
2.  **Organized QR Code Library:**
    * Save your created QR codes with custom names for easy retrieval.
    * Copy QR code images directly for immediate use.
    * Access and manage all saved QR codes from a centralized dashboard.
    * Quickly find QR codes with the built-in search functionality.
    * Easily copy shortcodes, download, or delete QR codes from the library.
3.  **Customizable Appearance:**
    * Personalize your QR codes by changing eye and dot colors.
    * Select from various eye and dot styles to match your brand.
    * Adjust the QR code image size to fit your needs.
4.  **Dynamic Gradient Effects:**
    * Add eye-catching gradient colors to your QR codes for a modern look.
5.  **Advanced QR Code Types:**
    * Create QR codes for vCards, maps, and phone numbers, expanding your communication options.
6.  **Integrated Meta-Box:**
    * Generate QR codes for specific pages or posts using the convenient meta-box.
7.  **Flexible Shortcode Integration:**
    * Embed QR codes anywhere on your website using simple shortcodes.
8.  **Automated QR codes**
    * Create automated shortcode in all pages, posts and woocommerce products.
    * You can design the QR code as your own from QR Design
9.  **Enhanced QR code in any place of Page with Block:**
    * Add QR codes at any parts your pages using our easy to use block.
    * This block is available on all kinds of editors like gutenberg, wpbakery, elementor etc.

## Pro Version: Supercharge Your QR Code Capabilities

1.  **Everything in the Free Version, Plus:**
    * Enjoy all the features of the free version, with enhanced capabilities.
2.  **Brand Integration with Logos:**
    * Incorporate your logo into QR codes to reinforce your brand identity.
3.  **Automated WooCommerce Integration:**
    * Automatically add QR codes to customer order pages for information sharing.
    * Automatically add QR codes to each product page.
    * Track your url with QR Code (coming soon)
4.  **Pro Suport**
    * For pro plugin you will get direct support from our expert team


[Try the Demo](https://devsbrain.com/wordpress-plugins/flex-qr-code-generator/ "Pro Demo Devs Accounting") | [Premium version](https://devsbrain.com/wordpress-plugins/flex-qr-code-generator/) | [Documents](https://devsbrain.com/wordpress-plugins/flex-qr-code-generator/ "Documents")
= Privacy =

This plugin does not connect to any third-party applications. It does not collect or store any user information. This plugin only generates QR Code image.

= Feedback =
Any suggestions or feedback are welcome, thank you for using or trying my plugin. Please let me know about your experience and rate this plugin.

###And many more things are waiting for you to discover

[GET PRO VERSION](https://devsbrain.com/wordpress-plugins/flex-qr-code-generator/)

= Need Any Help? =
* Please mail us at `contact@devsbrain.com`
* We provide live support

== Screenshots ==
1. The admin view of create QR Code design screenshot-1.png
2. The QR Code Create form in admin screenshot-2.png
3. Show created QR code grids screenshot-3.png 
4. Add QR code block in any page or post with wp default editor(pro)  screenshot-4.png
5. Show Flex QR Code settings page screenshot-5.png
6. Customize QR code design for Woocommerce pages (pro) screenshot-6.png
7. Show QR code on woocommerce product page (pro) screenshot-7.png
8. Add QR code block from gutenberg editor screenshot-8.png
9. Show QR Metabox in posts page screenshot-7.png

## Installation
1. Login to your WordPress admin dashboard.
2. Go to Plugins > Add New.
3. Click on the "Upload Plugin" button.
4. Choose the plugin zip file and click on the "Install Now" button.
5. Activate the plugin and check it in the settings link.

## Usage
1. Go to QR Code > Add New.
2. Enter the information for the QR code you want to create.
   a. You can select page, post or products from the select dropdown to append url
3. Customize the color, design, and eye style of your QR code.
4. Click on the "Generate QR Code" button.
5. View and download all your created QR codes from the QR Code > QR Codes page.
6. Copy the shortcode and show it in any places where you want
7. You can enable post metabox for any posts from settings
8. Go to Edit post and can see the meta box with QR code and shortcode. You can download QR code from there

## Requirements
- WordPress 4.0 or higher
- PHP 7.2.2 or higher

## License
This plugin is licensed under the GPLv2 (or later) license.

## Support
If you need any assistance or have any questions about the plugin, please open a support ticket and we will be happy to help.

## Contribution
If you want to contribute to the development of the plugin, you can submit a pull request on the plugin's Github repository.

## Changelog
### 1.0.0
- Initial release
### 1.1.1
- Add shortcode to show the shortcode easily
- Add Delete shortcode options
- Add pagination in the shortcodes table
### 1.1.2
- Add automatic page/post/product url selection
### 1.1.3
- Add post metabox for generating QR code and shortcode for that posts
- Settings page added for showing post metabox and qrcode download button
### 1.1.4
- Update security validation
### 1.1.5
- fixing bugs for generated qr code from posts
- Tracking qrcode 
### 1.1.6
- qr code eps file bug fixed
- qr code table fixed for eps file
### 1.1.7
- post page qr code download format option added
### 1.2.0
- Add selft hosted js library to generate qr code
- Add custom color for qrcode eye
- Add create qr design with js like single page
- Update created QR code design table to grid 
### 1.2.1
- Add gradient color for all qrcodes
- Add automatic qr code for all pages and posts and woocommerce (pro)
- Add logo in QR Code (pro)
- Add Flex Qr Code Block on WP gutenberg editor, wpbakery, elementor and others
### 1.2.2
- Fix QR code add tab change data loss
- fix QR code design tab change data loss
- Update QR code preview design
### 1.2.3
- Improve FlexQR Code block interaction
- Enhance QR cards UI in library
- Add QR image modal for enlarged preview
- Add scan counter for QR codes
- Add scan QR tracking details (pro)
### 1.2.4
- Add QR code editing functionality  
- Fix QR generated by metabox sometimes not appearing  
- Fix vCard organization field handling  
- Improve minor UI details 
### 1.2.5
- Add QR code sharing functionality
- Improve QR preview modal design/usability
- Improve QR updating logic
- Fix logo uploading logic

### 1.2.6
- Fixed plugin issue
- Fixed qr code image vulnarabilty issue