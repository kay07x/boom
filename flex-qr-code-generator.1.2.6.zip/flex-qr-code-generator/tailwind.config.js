import colors from 'tailwindcss/colors';

export const mode = 'jit';
export const content = ['./**/*.php', '!./node_modules/**/*', './src/**/*.js'];

export const theme = {
  extend: {
    fontFamily: {
      inter: 'Inter',
      gugi: ['Gugi', 'serif'],
    },
    colors: {
      primary: colors.blue,
    },
  },
};

export const plugins = [
  // import('@tailwindcss/forms'),
];
