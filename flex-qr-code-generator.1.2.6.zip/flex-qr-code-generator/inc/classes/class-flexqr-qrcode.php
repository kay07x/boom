<?php

declare(strict_types=1);

use chillerlan\QRCode\{QRCode, QROptions};
use chillerlan\QRCode\Common\EccLevel;
use chillerlan\QRCode\Data\QRMatrix;
use chillerlan\QRCode\Output\{QRMarkupSVG, QRGdImage, QRGdImagePNG, QRCodeOutputException, QRInterventionImage, QRMarkupXML};
use chillerlan\QRCode\Output\QRGdImageJPEG;
use chillerlan\QRCode\Output\QREps;

if (!class_exists('FlexQr_QRCode')) {

    class FlexQr_QRCode
    {
        private $qr_text;
        public $eye_color;
        public $dot_color;
        public $version;
        private $qr_style;
        private $size;
        public $margin;
        public $qrCodeSize;
        //   private $format;
        private $logo_path;
        private $draw_circular_modules;
        private $circleRadius;
        public $qr_code_logo;
        public $isConnectPaths;
        public $isRainbowMode;


        public function __construct($data = [])
        {
            if (empty($data)) {
                $data = $_POST;
            }

            $this->qr_text = !empty($data['qr_code_text']) ? (string) $data["qr_code_text"] : 'Flex Qr Code Generagor By devsbrain';
            // $this->qr_text = $data['qr_code_text'] ?? 'Flex Qr Code Generagor By devsbrain';

            $this->eye_color = $data['eye_color'] ?? '#000000';
            $this->dot_color = $data['dot_color'] ?? '#000000';
            $this->version = !empty($data['version']) ? (int) $data["version"] : 7;
            // echo '' . $this->version . '';
            // $this->qrCodeSize = (int) ($data['qr_code_size'] ?? 150);
            // $this->margin = (int) ($data['qr_code_margin'] ?? 10);
            // $this->circleRadius = (float) $data['circleRadius'] ?? 0.5;
            // $this->draw_circular_modules = $data['drawCircularModules'] == 1 ? true : false;

            $this->qrCodeSize = !empty($data['qr_code_size']) ? (int) $data["qr_code_size"] : 150;
            $this->margin = !empty($data['qr_code_margin']) ? (int) $data["qr_code_margin"] : 5;

            $this->circleRadius = !empty($data['circleRadius']) ? (float) $data["circleRadius"] : 0.5;
            $this->draw_circular_modules = !empty($data['drawCircularModules']) && $data['drawCircularModules'] == 1;

            $this->qr_code_logo = $data['qr_code_logo'] ?? null;

            if (!empty($data['is_connect_paths'])) {
                $this->isConnectPaths = filter_var($data["is_connect_paths"], FILTER_VALIDATE_BOOLEAN);
            } else {
                $this->isConnectPaths = false;
            }

            // rainbow 
            if (!empty($data['is_rainbow_mode'])) {
                $this->isRainbowMode = filter_var($data["is_rainbow_mode"], FILTER_VALIDATE_BOOLEAN);
            } else {
                $this->isRainbowMode = false;
            }
        }



        public function generate($fileType = 'svg')
        {
            $colors = [
                    // finder
                QRMatrix::M_FINDER_DARK => $this->eye_color, // dark (true)//eye color
                QRMatrix::M_FINDER_DOT => $this->eye_color, // finder dot, dark (true) eye color
                    // QRMatrix::M_FINDER         => $this->eye_color, // light (false), eye color
                    // // alignment
                QRMatrix::M_ALIGNMENT_DARK => $this->dot_color, //center eye color
                    // QRMatrix::M_ALIGNMENT      => $this->eye_color,//center eye inner color 
                    // // timing
                QRMatrix::M_TIMING_DARK => $this->dot_color, //center line dot color    
                QRMatrix::M_TIMING => $this->dot_color,
                    // format
                    // QRMatrix::M_FORMAT_DARK    => $dot_background_color,
                QRMatrix::M_FORMAT_DARK => $this->dot_color,
                    // QRMatrix::M_FORMAT         => $this->dot_color, //enable this scan code is not working
                    // version
                QRMatrix::M_VERSION_DARK => $this->dot_color,
                    // QRMatrix::M_VERSION => $this->dot_color,
                    // data
                QRMatrix::M_DATA_DARK => $this->dot_color, //dot_color
                    // QRMatrix::M_DATA           => $this->dot_color, //dot background color
                    // darkmodule
                QRMatrix::M_DARKMODULE => $this->dot_color,
                // separator
                // QRMatrix::M_SEPARATOR      => $this->dot_color,
                // quietzone
                // QRMatrix::M_QUIETZONE      => $this->qr_code_bg_color, //background_color
                // logo (requires a call to QRMatrix::setLogoSpace()), see QRImageWithLogo
                // QRMatrix::M_LOGO           => '#b105f0',

                // 1536 => 'url(#gradient)', // finder
                // 6    => '#39FFFF', // dark (data)
                // 8    => 'url(#gradient)', // alignment
                // 2560 => '#c91414', // format
                // 10   => 'url(#gradient)', // version
            ];
            $options = new QROptions;
            $options->version = $this->version;
            // ecc level H is required for logo space
            $options->eccLevel = EccLevel::H;
            // $options->imageBase64          = true;
            $options->scale = 6;
            $options->outputBase64 = true;

            $options->drawCircularModules = $this->draw_circular_modules;
            $options->drawLightModules = true;
            $options->circleRadius = $this->circleRadius; //works only when 
            $options->moduleValues = $colors;
            $options->quietzoneSize = $this->margin;

            $options->connectPaths = $this->isConnectPaths;

            // Rainbow Mode
            if ($this->isRainbowMode) {
                $offset = 0.6;
                $options->svgDefs = '
                    <linearGradient id="rainbow" x1="1" y2="1">
                    <stop stop-color="' . $this->eye_color . '" offset="0"/>
                    <stop stop-color="' . $this->dot_color . '" offset="' . $offset . '"/>
                    </linearGradient>
                    <style><![CDATA[
                    .dark{fill: url(#rainbow);}
                    .light{fill: #eee;}
                    ]]></style>';
            }

            $logoPath = null;

            // Logo in files or in data
            if (isset($_FILES['qr_code_logo']) && $_FILES['qr_code_logo']['error'] === UPLOAD_ERR_OK) {
                $logoPath = $this->saveUploadedLogo($_FILES['qr_code_logo']);
            } else if ($this->qr_code_logo) {
                $logoPath = $this->qr_code_logo;
            }

            if (!empty($logoPath) && $logoPath !== 'undefined' && $logoPath !== 'null') {
                $options->addLogoSpace = true;
                $options->logoSpaceWidth = 15; // Adjust logo width
                $options->logoSpaceHeight = 15; // Adjust logo height
                $qrImage = (new QRCode($options));
                $qrImage->addByteSegment($this->qr_text);

                $qrOutputInterface = new QRImageWithLogo($options, $qrImage->getQRMatrix());

                $out = $qrOutputInterface->dump(null, $logoPath);

                // $out = $qrImage->render();

                // header('Content-type: image/png');

                return [$out, $logoPath];
            }


            // doesnot work
            if ($fileType === 'eps') {

                $qrImage = (new QRCode($options))->render($this->qr_text);

                header('Content-type: application/postscript');

                return [$qrImage, null];
            }

            // Generate the QR Code
            $qrImage = (new QRCode($options))->render($this->qr_text);

            // header('Content-type: image/png');

            return [$qrImage, null];

        }

        /**
         * Saves the uploaded logo file temporarily and returns its path.
         */
        private function saveUploadedLogo($file)
        {
            $allowedTypes = ['image/png', 'image/jpeg', 'image/jpg'];

            if (!in_array($file['type'], $allowedTypes)) {
                throw new QRCodeOutputException('Invalid file type. Only PNG and JPEG are allowed.');
            }

            $filename = 'logo_' . uniqid() . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = preg_replace(['/[^a-zA-Z0-9_\.]/', '/\.+/'], ['', '.'], $filename);
            $filename = str_replace(' ', '_', $filename);

            $full_path = WP_CONTENT_DIR . '/uploads/' . $filename;

            if (!move_uploaded_file($file['tmp_name'], $full_path)) {
                throw new QRCodeOutputException('Failed to move the uploaded file.');
            }

            return $full_path;
        }

    }
}

// class QRImageWithLogo extends QRGdImagePNG
// {

//     /**
//      * @throws \chillerlan\QRCode\Output\QRCodeOutputException
//      */
//     public function dump(string|null $file = null, string|null $logo = null): string
//     {
//         $logo ??= '';

//         // var_dump($logo);

//         // set returnResource to true to skip further processing for now
//         $this->options->returnResource = true;

//         // of course, you could accept other formats too (such as resource or Imagick)
//         // I'm not checking for the file type either for simplicity reasons (assuming PNG)
//         if (!is_file($logo) || !is_readable($logo)) {
//             throw new QRCodeOutputException('invalid logo');
//         }

//         // there's no need to save the result of dump() into $this->image here
//         parent::dump($file);

//         $im = imagecreatefrompng($logo);

//         if ($im === false) {
//             throw new QRCodeOutputException('imagecreatefrompng() error');
//         }

//         // get logo image size
//         $w = imagesx($im);
//         $h = imagesy($im);

//         // set new logo size, leave a border of 1 module (no proportional resize/centering)
//         $lw = (($this->options->logoSpaceWidth - 2) * $this->options->scale);
//         $lh = (($this->options->logoSpaceHeight - 2) * $this->options->scale);

//         // get the qrcode size
//         $ql = ($this->matrix->getSize() * $this->options->scale);

//         // scale the logo and copy it over. done!
//         imagecopyresampled($this->image, $im, (($ql - $lw) / 2), (($ql - $lh) / 2), 0, 0, $lw, $lh, $w, $h);

//         $imageData = $this->dumpImage();

//         $this->saveToFile($imageData, $file);

//         if ($this->options->outputBase64) {
//             $imageData = $this->toBase64DataURI($imageData);
//         }

//         return $imageData;
//     }

// }

class QRImageWithLogo extends QRGdImagePNG
{
    protected QROptions $storedOptions;

    /**
     * Constructor to store the options
     */
    public function __construct(QROptions $options, QRMatrix $matrix)
    {
        parent::__construct($options, $matrix);
        $this->storedOptions = clone $options; // Store a copy of the options
    }

    /**
     * @throws \chillerlan\QRCode\Output\QRCodeOutputException
     */
    public function dump(string|null $file = null, string|null $logo = null): string
    {
        $logo ??= '';

        // Set returnResource to true to skip further processing for now
        $this->options->returnResource = true;

        // Validate the logo file
        if (!is_file($logo) || !is_readable($logo)) {
            throw new QRCodeOutputException('Invalid logo file');
        }

        // Generate the base QR code image
        // parent::dump($file);
        parent::dump($file);

        // Load the logo image
        $im = imagecreatefrompng($logo);
        if ($im === false) {
            throw new QRCodeOutputException('Failed to load logo image');
        }

        // Get logo dimensions
        $logoWidth = imagesx($im);
        $logoHeight = imagesy($im);

        // Calculate the size for the logo space
        $logoSpaceWidth = ($this->options->logoSpaceWidth - 2) * $this->options->scale;
        $logoSpaceHeight = ($this->options->logoSpaceHeight - 2) * $this->options->scale;

        // Get the QR code size
        $qrSize = $this->matrix->getSize() * $this->options->scale;

        // Calculate the position to center the logo
        $logoX = ($qrSize - $logoSpaceWidth) / 2;
        $logoY = ($qrSize - $logoSpaceHeight) / 2;

        // Resize and place the logo on the QR code
        imagecopyresampled(
            $this->image, // Destination image (QR code)
            $im,         // Source image (logo)
            $logoX,      // Destination X
            $logoY,      // Destination Y
            0,           // Source X
            0,           // Source Y
            $logoSpaceWidth,  // Destination width
            $logoSpaceHeight, // Destination height
            $logoWidth,  // Source width
            $logoHeight  // Source height
        );

        // Reapply the stored options after adding the logo
        $this->reapplyOptions();

        // Generate the final image data
        $imageData = $this->dumpImage();

        // Save the image to a file if a file path is provided
        $this->saveToFile($imageData, $file);

        // Return the image data as a base64-encoded string if required
        if ($this->options->outputBase64) {
            $imageData = $this->toBase64DataURI($imageData);
        }

        return $imageData;
    }

    /**
     * Reapply the stored options after adding the logo
     */
    protected function reapplyOptions(): void
    {
        // Reapply the stored options
        foreach ($this->storedOptions as $key => $value) {
            $this->options->$key = $value;
        }

        // Reapply module values
        $this->applyModuleValues();
    }

    /**
     * Apply module values explicitly after adding the logo
     */
    protected function applyModuleValues(): void
    {
        // Ensure the image resource is available
        if ($this->image === null) {
            throw new QRCodeOutputException('Image resource is not available');
        }

        // Check if connectPaths is enabled
        if (!$this->options->connectPaths) {
            // Use gradient for .dark modules
            foreach ($this->options->moduleValues as $M_TYPE => $color) {
                if (strpos($color, 'url(#gradient)') !== false) {
                    $this->setModuleValuesForType($M_TYPE, $this->options->svgDefs);
                } else {
                    $this->setModuleValuesForType($M_TYPE, $color);
                }
            }
        } else {
            // Use single color (dot_color) for all modules
            $singleColor = $this->options->moduleValues[QRMatrix::M_DATA_DARK] ?? '#000000'; // Fallback to black
            foreach ($this->options->moduleValues as $M_TYPE => $color) {
                $this->setModuleValuesForType($M_TYPE, $singleColor);
            }
        }
    }

    /**
     * Set module values for a specific module type
     */
    protected function setModuleValuesForType(int $M_TYPE, string $color): void
    {
        // Loop through the matrix and apply the color to the specified module type
        foreach ($this->matrix->getMatrix() as $y => $row) {
            foreach ($row as $x => $value) {
                if ($value === $M_TYPE) {
                    // Apply the color to the entire module (scaled)
                    $this->fillModule($x, $y, $color);
                }
            }
        }
    }

    /**
     * Fill a module with the specified color
     */
    protected function fillModule(int $x, int $y, string $color): void
    {
        $color = $this->getColor($color);
        $scale = $this->options->scale;

        // Calculate the starting and ending coordinates for the module
        $startX = $x * $scale;
        $startY = $y * $scale;
        $endX = $startX + $scale;
        $endY = $startY + $scale;

        // Fill the module with the specified color
        imagefilledrectangle($this->image, $startX, $startY, $endX, $endY, $color);
    }

    /**
     * Convert a color string to a GD color identifier
     */
    protected function getColor(string $color): int
    {
        if ($color === 'url(#gradient)') {
            // Handle gradient colors
            return imagecolorallocate($this->image, 0, 0, 0); // Default to black
        }
        return imagecolorallocatealpha(
            $this->image,
            hexdec(substr($color, 1, 2)),
            hexdec(substr($color, 3, 2)),
            hexdec(substr($color, 5, 2)),
            0 // Alpha (0 = fully opaque)
        );
    }
}