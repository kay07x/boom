module.exports = {
  plugins: [
    require('tailwindcss'),
    require('autoprefixer'),
    require('postcss-nested'), // Add other PostCSS plugins as needed
  ],
};
